<?php
require_once __DIR__ . '/../config.php';

function obtenerUsuariosPorAlmacen(int $idAlmacen): void {
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('SELECT id, nombre, rol, id_almacen FROM usuarios WHERE id_almacen = ? ORDER BY nombre');
        $stmt->execute([$idAlmacen]);
        responder(200, $stmt->fetchAll());
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}

function crearUsuario(array $body): void {
    $nombre    = trim($body['nombre'] ?? '');
    $rol       = trim($body['rol'] ?? '');
    $idAlmacen = (int)($body['id_almacen'] ?? 0);

    if ($nombre === '' || $idAlmacen === 0) {
        responder(400, ['error' => 'Los campos nombre e id_almacen son obligatorios']);
    }
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('INSERT INTO usuarios (nombre, rol, id_almacen) VALUES (?, ?, ?)');
        $stmt->execute([$nombre, $rol ?: null, $idAlmacen]);
        responder(201, [
            'id'        => (int)$pdo->lastInsertId(),
            'nombre'    => $nombre,
            'rol'       => $rol ?: null,
            'id_almacen'=> $idAlmacen,
        ]);
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}
