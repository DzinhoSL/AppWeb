<?php
require_once __DIR__ . '/../config.php';

function obtenerAlmacenes(): void {
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->query('SELECT id, nombre FROM almacenes ORDER BY id');
        responder(200, $stmt->fetchAll());
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}

function crearAlmacen(array $body): void {
    $nombre = trim($body['nombre'] ?? '');
    if ($nombre === '') {
        responder(400, ['error' => 'El campo nombre es obligatorio']);
    }
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('INSERT INTO almacenes (nombre) VALUES (?)');
        $stmt->execute([$nombre]);
        responder(201, ['id' => (int)$pdo->lastInsertId(), 'nombre' => $nombre]);
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}
