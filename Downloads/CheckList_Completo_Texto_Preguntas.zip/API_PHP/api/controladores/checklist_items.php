<?php
require_once __DIR__ . '/../config.php';

function obtenerItemsPorMaquina(int $idMaquina): void {
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('SELECT id, id_maquina, descripcion FROM checklist_items WHERE id_maquina = ? ORDER BY id');
        $stmt->execute([$idMaquina]);
        responder(200, $stmt->fetchAll());
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}

function crearItem(array $body): void {
    $descripcion = trim($body['descripcion'] ?? '');
    $idMaquina   = (int)($body['id_maquina'] ?? 0);

    if ($descripcion === '' || $idMaquina === 0) {
        responder(400, ['error' => 'Los campos descripcion e id_maquina son obligatorios']);
    }
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('INSERT INTO checklist_items (id_maquina, descripcion) VALUES (?, ?)');
        $stmt->execute([$idMaquina, $descripcion]);
        responder(201, [
            'id'          => (int)$pdo->lastInsertId(),
            'id_maquina'  => $idMaquina,
            'descripcion' => $descripcion,
        ]);
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}
