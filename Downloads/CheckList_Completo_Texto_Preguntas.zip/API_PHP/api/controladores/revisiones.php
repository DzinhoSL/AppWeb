<?php
require_once __DIR__ . '/../config.php';

function obtenerRevisiones(): void {
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->query('SELECT id, id_usuario, id_maquina, fecha_hora, firma, tiene_fallos FROM revisiones ORDER BY fecha_hora DESC');
        responder(200, $stmt->fetchAll());
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}

function obtenerRevisionesPorMaquina(int $idMaquina): void {
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('SELECT id, id_usuario, id_maquina, fecha_hora, firma, tiene_fallos FROM revisiones WHERE id_maquina = ? ORDER BY fecha_hora DESC');
        $stmt->execute([$idMaquina]);
        responder(200, $stmt->fetchAll());
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}

function obtenerRevisionesPorUsuario(int $idUsuario): void {
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('SELECT id, id_usuario, id_maquina, fecha_hora, firma, tiene_fallos FROM revisiones WHERE id_usuario = ? ORDER BY fecha_hora DESC');
        $stmt->execute([$idUsuario]);
        responder(200, $stmt->fetchAll());
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}

function crearRevision(array $body): void {
    $idUsuario   = (int)($body['id_usuario'] ?? 0);
    $idMaquina   = (int)($body['id_maquina'] ?? 0);
    $fechaHora   = trim($body['fecha_hora'] ?? '');
    $firma       = $body['firma'] ?? null;
    $tieneFallos = !empty($body['tiene_fallos']) ? 1 : 0;
    $comentario  = $body["comentario"] ?? null;
    $preguntasFallidas = $body["preguntas_fallidas"] ?? "[]"; // Valor por defecto JSON array vacío

    if ($idUsuario === 0 || $idMaquina === 0) {
        responder(400, ['error' => 'Los campos id_usuario e id_maquina son obligatorios']);
    }
    if ($fechaHora === '') {
        $fechaHora = date('Y-m-d H:i:s');
    }
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare(
            'INSERT INTO revisiones (id_usuario, id_maquina, fecha_hora, firma, tiene_fallos, comentario, preguntas_fallidas) VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$idUsuario, $idMaquina, $fechaHora, $firma, $tieneFallos, $comentario, $preguntasFallidas]);
        $id = (int)$pdo->lastInsertId();
        responder(201, [
            'id'           => $id,
            'id_usuario'   => $idUsuario,
            'id_maquina'   => $idMaquina,
            'fecha_hora'   => $fechaHora,
            'firma'        => $firma,
            'tiene_fallos' => (bool)$tieneFallos,
            'comentario'   => $comentario,
            'preguntas_fallidas' => json_decode($preguntasFallidas),
        ]);
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}