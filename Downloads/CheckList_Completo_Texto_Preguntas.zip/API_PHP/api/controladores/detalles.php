<?php
require_once __DIR__ . '/../config.php';

function obtenerDetallesPorRevision(int $idRevision): void {
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('SELECT id, id_revision, id_item, resultado, comentario FROM detalles WHERE id_revision = ? ORDER BY id');
        $stmt->execute([$idRevision]);
        responder(200, $stmt->fetchAll());
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}

function crearDetalle(array $body): void {
    $idRevision = (int)($body['id_revision'] ?? 0);
    $idItem     = (int)($body['id_item'] ?? 0);
    $resultado  = isset($body['resultado']) ? ($body['resultado'] ? 1 : 0) : null;
    $comentario = $body['comentario'] ?? null;

    if ($idRevision === 0 || $idItem === 0 || $resultado === null) {
        responder(400, ['error' => 'Los campos id_revision, id_item y resultado son obligatorios']);
    }
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('INSERT INTO detalles (id_revision, id_item, resultado, comentario) VALUES (?, ?, ?, ?)');
        $stmt->execute([$idRevision, $idItem, $resultado, $comentario]);
        responder(201, [
            'id'          => (int)$pdo->lastInsertId(),
            'id_revision' => $idRevision,
            'id_item'     => $idItem,
            'resultado'   => (bool)$resultado,
            'comentario'  => $comentario,
        ]);
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}
