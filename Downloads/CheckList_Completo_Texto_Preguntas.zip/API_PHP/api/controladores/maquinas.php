<?php
require_once __DIR__ . '/../config.php';

function obtenerMaquinasPorAlmacen(int $idAlmacen): void {
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('SELECT id, nombre, id_almacen FROM maquinas WHERE id_almacen = ? ORDER BY nombre');
        $stmt->execute([$idAlmacen]);
        responder(200, $stmt->fetchAll());
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}

function crearMaquina(array $body): void {
    $nombre    = trim($body['nombre'] ?? '');
    $idAlmacen = (int)($body['id_almacen'] ?? 0);

    if ($nombre === '' || $idAlmacen === 0) {
        responder(400, ['error' => 'Los campos nombre e id_almacen son obligatorios']);
    }
    try {
        $pdo  = obtenerConexion();
        $stmt = $pdo->prepare('INSERT INTO maquinas (nombre, id_almacen) VALUES (?, ?)');
        $stmt->execute([$nombre, $idAlmacen]);
        responder(201, [
            'id'         => (int)$pdo->lastInsertId(),
            'nombre'     => $nombre,
            'id_almacen' => $idAlmacen,
        ]);
    } catch (Exception $e) {
        responder(500, ['error' => $e->getMessage()]);
    }
}
