<?php
// =====================================================
//  CONFIGURACIÓN DE BASE DE DATOS
//  Rellena estos valores con tus credenciales reales
// =====================================================

define('DB_HOST', '34.175.97.39');        // ej: localhost  o  127.0.0.1  o  el host que te dieron
define('DB_NAME', 'dbcbwkixgjgvv2');   // ej: panelsandwich_db
define('DB_USER', 'updbfnvjhzzgw');     // ej: root  o  ps_user
define('DB_PASS', 'ptz8ldrijimg');  // ej: miPassword123
define('DB_CHARSET', 'utf8mb4');

function obtenerConexion(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $opciones = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $opciones);
    }
    return $pdo;
}
