<?php
// =====================================================
//  API REST - CheckList App Panel Sandwich
//  Punto de entrada principal (router)
// =====================================================

require_once __DIR__ . '/config.php';

// Cabeceras CORS y JSON
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');

// Responder a preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Parsear la ruta quitando el prefijo /api/
$uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri    = preg_replace('#^/api/?#', '', $uri);
$uri    = trim($uri, '/');
$partes = explode('/', $uri);
$metodo = $_SERVER['REQUEST_METHOD'];

// Leer body JSON
$body = [];
$rawBody = file_get_contents('php://input');
if (!empty($rawBody)) {
    $body = json_decode($rawBody, true) ?? [];
}

// -------------------------------------------------------
//  Función helper: respuesta JSON
// -------------------------------------------------------
function responder(int $codigo, mixed $datos): void {
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

// -------------------------------------------------------
//  ENRUTAMIENTO
// -------------------------------------------------------

// GET /health
if ($metodo === 'GET' && $partes[0] === 'health') {
    responder(200, ['status' => 'ok', 'timestamp' => date('Y-m-d H:i:s')]);
}

// ---- ALMACENES ----
// GET /almacenes
if ($metodo === 'GET' && $partes[0] === 'almacenes' && !isset($partes[1])) {
    require_once __DIR__ . '/controladores/almacenes.php';
    obtenerAlmacenes();
}
// POST /almacenes
if ($metodo === 'POST' && $partes[0] === 'almacenes') {
    require_once __DIR__ . '/controladores/almacenes.php';
    crearAlmacen($body);
}

// ---- USUARIOS ----
// GET /usuarios/almacen/{idAlmacen}
if ($metodo === 'GET' && $partes[0] === 'usuarios' && ($partes[1] ?? '') === 'almacen' && isset($partes[2])) {
    require_once __DIR__ . '/controladores/usuarios.php';
    obtenerUsuariosPorAlmacen((int)$partes[2]);
}
// POST /usuarios
if ($metodo === 'POST' && $partes[0] === 'usuarios') {
    require_once __DIR__ . '/controladores/usuarios.php';
    crearUsuario($body);
}

// ---- MÁQUINAS ----
// GET /maquinas/almacen/{idAlmacen}
if ($metodo === 'GET' && $partes[0] === 'maquinas' && ($partes[1] ?? '') === 'almacen' && isset($partes[2])) {
    require_once __DIR__ . '/controladores/maquinas.php';
    obtenerMaquinasPorAlmacen((int)$partes[2]);
}
// POST /maquinas
if ($metodo === 'POST' && $partes[0] === 'maquinas') {
    require_once __DIR__ . '/controladores/maquinas.php';
    crearMaquina($body);
}

// ---- CHECKLIST ITEMS ----
// GET /checklist_items/maquina/{idMaquina}
if ($metodo === 'GET' && $partes[0] === 'checklist_items' && ($partes[1] ?? '') === 'maquina' && isset($partes[2])) {
    require_once __DIR__ . '/controladores/checklist_items.php';
    obtenerItemsPorMaquina((int)$partes[2]);
}
// POST /checklist_items
if ($metodo === 'POST' && $partes[0] === 'checklist_items') {
    require_once __DIR__ . '/controladores/checklist_items.php';
    crearItem($body);
}

// ---- REVISIONES ----
// GET /revisiones
if ($metodo === 'GET' && $partes[0] === 'revisiones' && !isset($partes[1])) {
    require_once __DIR__ . '/controladores/revisiones.php';
    obtenerRevisiones();
}
// GET /revisiones/maquina/{idMaquina}
if ($metodo === 'GET' && $partes[0] === 'revisiones' && ($partes[1] ?? '') === 'maquina' && isset($partes[2])) {
    require_once __DIR__ . '/controladores/revisiones.php';
    obtenerRevisionesPorMaquina((int)$partes[2]);
}
// GET /revisiones/usuario/{idUsuario}
if ($metodo === 'GET' && $partes[0] === 'revisiones' && ($partes[1] ?? '') === 'usuario' && isset($partes[2])) {
    require_once __DIR__ . '/controladores/revisiones.php';
    obtenerRevisionesPorUsuario((int)$partes[2]);
}
// POST /revisiones
if ($metodo === 'POST' && $partes[0] === 'revisiones') {
    require_once __DIR__ . '/controladores/revisiones.php';
    crearRevision($body);
}

// ---- DETALLES ----
// GET /detalles/revision/{idRevision}
if ($metodo === 'GET' && $partes[0] === 'detalles' && ($partes[1] ?? '') === 'revision' && isset($partes[2])) {
    require_once __DIR__ . '/controladores/detalles.php';
    obtenerDetallesPorRevision((int)$partes[2]);
}
// POST /detalles
if ($metodo === 'POST' && $partes[0] === 'detalles') {
    require_once __DIR__ . '/controladores/detalles.php';
    crearDetalle($body);
}

// Si no se encontró ninguna ruta
responder(404, ['error' => 'Ruta no encontrada', 'uri' => $uri]);
