-- Script para actualizar la tabla de revisiones en el servidor (Adminer/MySQL)
-- Añade el campo preguntas_fallidas para almacenar los IDs de las preguntas con resultado "No" en formato JSON.

ALTER TABLE `revisiones` 
ADD COLUMN `preguntas_fallidas` JSON DEFAULT (JSON_ARRAY()) 
AFTER `tiene_fallos`;

-- Nota: Si tu versión de MySQL es inferior a 5.7 (donde no existe el tipo JSON), 
-- usa la siguiente línea en su lugar (descomentándola):
-- ALTER TABLE `revisiones` ADD COLUMN `preguntas_fallidas` TEXT AFTER `tiene_fallos`;
