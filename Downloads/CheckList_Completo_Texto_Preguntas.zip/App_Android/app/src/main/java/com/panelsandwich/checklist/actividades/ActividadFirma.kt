package com.panelsandwich.checklist.actividades

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.panelsandwich.checklist.R
import com.panelsandwich.checklist.basedatos.Repositorio
import com.panelsandwich.checklist.modelos.*
import com.panelsandwich.checklist.utilidades.Utilidades
import com.panelsandwich.checklist.vistas.VistaFirma
import kotlinx.coroutines.launch

private const val TAG = "DEBUG_FIRMA"

class ActividadFirma : AppCompatActivity() {

    private lateinit var vistaFirma: VistaFirma
    private lateinit var botonLimpiar: Button
    private lateinit var botonEnviar: Button
    private lateinit var botonAtras: Button
    private lateinit var progressBar: ProgressBar

    private lateinit var usuario: Usuario
    private lateinit var almacen: Almacen
    private lateinit var maquina: Maquina

    private val repositorio = Repositorio()

    companion object {
        const val EXTRA_USUARIO = "usuario"
        const val EXTRA_ALMACEN = "almacen"
        const val EXTRA_MAQUINA = "maquina"
        const val EXTRA_COMENTARIO_GENERAL = "comentario_general"
        const val EXTRA_HAY_FALLOS = "hay_fallos"
        const val EXTRA_PREGUNTAS_FALLIDAS = "preguntas_fallidas"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "▶ ActividadFirma onCreate()")
        setContentView(R.layout.actividad_firma)

        usuario = intent.getSerializableExtra(EXTRA_USUARIO) as Usuario
        almacen = intent.getSerializableExtra(EXTRA_ALMACEN) as Almacen
        maquina = intent.getSerializableExtra(EXTRA_MAQUINA) as Maquina
        val comentarioGeneral = intent.getStringExtra(EXTRA_COMENTARIO_GENERAL) ?: ""
        val hayFallos = intent.getBooleanExtra(EXTRA_HAY_FALLOS, false)
        val preguntasFallidas = intent.getStringArrayListExtra(EXTRA_PREGUNTAS_FALLIDAS) ?: arrayListOf()

        Log.d(TAG, "  usuario=${usuario.nombre} (id=${usuario.id}), maquina=${maquina.nombre} (id=${maquina.id}), hayFallos=$hayFallos, comentario='$comentarioGeneral'")

        // Verificar que los resultados llegaron correctamente
        val resultadosRaw = intent.getSerializableExtra("resultados")
        Log.d(TAG, "  resultadosRaw tipo: ${resultadosRaw?.javaClass?.name ?: "NULL"}")

        vistaFirma = findViewById(R.id.vistaFirmaActividad)
        botonLimpiar = findViewById(R.id.botonLimpiarFirma)
        botonEnviar = findViewById(R.id.botonEnviarFirma)
        botonAtras = findViewById(R.id.botonAtrasActividad)
        progressBar = findViewById(R.id.progressBarFirma)

        botonLimpiar.setOnClickListener {
            Log.d(TAG, "  Botón LIMPIAR pulsado")
            vistaFirma.limpiar()
            Toast.makeText(this, "Firma limpiada", Toast.LENGTH_SHORT).show()
        }

        botonEnviar.setOnClickListener {
            Log.d(TAG, "  Botón ENVIAR pulsado")
            validarYEnviar(comentarioGeneral, hayFallos)
        }

        botonAtras.setOnClickListener {
            Log.d(TAG, "  Botón ATRÁS pulsado")
            finish()
        }

        Log.d(TAG, "✅ ActividadFirma onCreate() completado")
    }

    private fun validarYEnviar(comentarioGeneral: String, hayFallos: Boolean, preguntasFallidas: List<String>) {
        Log.d(TAG, "▶ validarYEnviar() — firma vacía: ${vistaFirma.estaVacia()}")
        if (vistaFirma.estaVacia()) {
            Log.w(TAG, "⚠ Firma vacía, no se puede enviar")
            Toast.makeText(this, "Por favor firma antes de enviar", Toast.LENGTH_SHORT).show()
            return
        }
        Log.d(TAG, "✅ Firma presente, procediendo al envío")
        enviarChecklist(comentarioGeneral, hayFallos, preguntasFallidas)
    }

    private fun enviarChecklist(comentarioGeneral: String, hayFallos: Boolean, preguntasFallidas: List<String>) {
        Log.d(TAG, "▶ enviarChecklist() iniciado")
        mostrarCargando(true)
        val firma = vistaFirma.obtenerFirmaBase64()
        val fechaHora = Utilidades.obtenerFechaHoraMysql()
        Log.d(TAG, "  firma obtenida: ${firma.length} chars, fechaHora=$fechaHora")

        lifecycleScope.launch {
            try {
                // PASO 1: Crear revisión
                val revision = Revision(
                    idUsuario = usuario.id,
                    idMaquina = maquina.id,
                    fechaHora = fechaHora,
                    firma = firma,
                    tieneFallos = hayFallos,
                    comentario = comentarioGeneral,
                    preguntasFallidas = preguntasFallidas
                )
                Log.d(TAG, "  PASO 1: Creando revisión...")
                val revisionCreada = repositorio.crearRevision(revision)

                if (revisionCreada != null) {
                    Log.d(TAG, "✅ PASO 1 OK — Revisión creada con ID: ${revisionCreada.id}")

                    // PASO 2: Obtener y procesar resultados
                    // BUGFIX: El cast de Serializable a Map<Int, Boolean?> puede fallar
                    // porque Java deserializa los genéricos sin información de tipo.
                    // Hacemos un cast seguro usando Any y luego convertimos manualmente.
                    @Suppress("UNCHECKED_CAST")
                    val resultadosRaw = intent.getSerializableExtra("resultados") as? Map<*, *>
                    Log.d(TAG, "  PASO 2: resultadosRaw=${if (resultadosRaw != null) "${resultadosRaw.size} entradas" else "NULL"}")

                    if (resultadosRaw != null) {
                        // Convertir Map<*, *> a Map<Int, Boolean?> de forma segura
                        val resultadosMap: Map<Int, Boolean?> = resultadosRaw.entries
                            .mapNotNull { (k, v) ->
                                val idItem = (k as? Int) ?: (k as? Number)?.toInt()
                                val resultado = v as? Boolean
                                if (idItem != null) idItem to resultado else null
                            }
                            .toMap()

                        Log.d(TAG, "  PASO 2: ${resultadosMap.size} resultados a enviar")

                        var detallesOK = 0
                        var detallesFallidos = 0

                        resultadosMap.forEach { (idItem, resultado) ->
                            if (resultado != null) {
                                val detalle = DetalleRevision(
                                    idRevision = revisionCreada.id,
                                    idItem = idItem,
                                    resultado = resultado
                                )
                                val detalleCreado = repositorio.crearDetalle(detalle)
                                if (detalleCreado != null) detallesOK++ else detallesFallidos++
                            } else {
                                Log.w(TAG, "  ⚠ idItem=$idItem tiene resultado NULL, se omite")
                            }
                        }

                        Log.d(TAG, "  PASO 2 completado — detallesOK=$detallesOK, detallesFallidos=$detallesFallidos")
                    } else {
                        Log.e(TAG, "❌ PASO 2: resultadosMap es NULL — no se guardarán detalles")
                    }

                    mostrarCargando(false)
                    Log.d(TAG, "✅ enviarChecklist() guardado localmente — intentando sincronizar con servidor...")

                    // Intentar sincronizar inmediatamente si hay WiFi
                    com.panelsandwich.checklist.sincronizacion.SincronizadorWifi.sincronizarSiHayWifi(this@ActividadFirma)

                    Toast.makeText(this@ActividadFirma, "Check-list guardado correctamente", Toast.LENGTH_LONG).show()

                    val intent = Intent(this@ActividadFirma, ActividadMenuPrincipal::class.java)
                    intent.putExtra(ActividadUsuarios.EXTRA_USUARIO, usuario)
                    intent.putExtra(ActividadUsuarios.EXTRA_ALMACEN, almacen)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                    startActivity(intent)

                } else {
                    Log.e(TAG, "❌ PASO 1 FALLÓ — revisionCreada es NULL")
                    mostrarCargando(false)
                    Toast.makeText(this@ActividadFirma, "Error al enviar el check-list. Inténtalo de nuevo.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "❌ enviarChecklist() EXCEPCIÓN no controlada: ${e.javaClass.simpleName}: ${e.message}", e)
                mostrarCargando(false)
                Toast.makeText(this@ActividadFirma, "Error de conexión: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun mostrarCargando(cargando: Boolean) {
        progressBar.visibility = if (cargando) android.view.View.VISIBLE else android.view.View.GONE
        botonEnviar.isEnabled = !cargando
        botonLimpiar.isEnabled = !cargando
        botonAtras.isEnabled = !cargando
    }
}
