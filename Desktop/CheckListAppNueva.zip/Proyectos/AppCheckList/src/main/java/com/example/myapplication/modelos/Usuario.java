package com.example.myapplication.modelos;

public class Usuario {
}
