package com.example.myapplication.actividades;

public class ActividadMaquinaria {
}
