package com.example.myapplication.modelos;

public class DetalleRevision {
}
