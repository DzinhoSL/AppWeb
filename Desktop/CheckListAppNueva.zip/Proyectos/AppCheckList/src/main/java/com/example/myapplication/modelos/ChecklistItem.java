package com.example.myapplication.modelos;

public class ChecklistItem {
}
