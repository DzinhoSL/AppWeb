package com.example.myapplication.base_datos;

public class GestorBaseDatos {
}
