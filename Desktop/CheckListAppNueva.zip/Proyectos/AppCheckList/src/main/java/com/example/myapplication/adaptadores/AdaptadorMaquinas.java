package com.example.myapplication.adaptadores;

public class AdaptadorMaquinas {
}
