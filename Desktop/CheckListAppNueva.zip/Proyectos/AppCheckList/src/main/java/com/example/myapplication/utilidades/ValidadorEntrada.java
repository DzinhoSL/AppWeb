package com.example.myapplication.utilidades;

public class ValidadorEntrada {
}
